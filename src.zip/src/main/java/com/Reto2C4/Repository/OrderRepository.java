package com.Reto2C4.Repository;

import com.Reto2C4.Entity.Order;
import com.Reto2C4.InterfaceCRUD.OrderInterface;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;



/**
 *
 * @author dyper
 */
@Repository
public class OrderRepository {

    @Autowired
    private OrderInterface orderCrudRepository;

    public List<Order> getAll() {
        return (List<Order>) orderCrudRepository.findAll();
    }

    public Optional<Order> getOrder(Integer id) {
        return orderCrudRepository.findById(id);
    }

    public Order create(Order order) {
        return orderCrudRepository.save(order);
    }
    /**
     * no va return porque es un void.
     * @param order 
     */
    public void update(Order order) {
        orderCrudRepository.save(order);
    }

    public void delete(Order order) {
        orderCrudRepository.delete(order);
    }
     public List<Order> getOrderByZone(String zone){
        return orderCrudRepository.findBySalesManZone(zone);
    }
    /*public Optional<Order> lastUserId(){
        return orderCrudRepository.findTopByOrderByIdDesc();
    }*/
}
