package com.Reto2C4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto2C4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
